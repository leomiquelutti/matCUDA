#pragma once

#define PI 3.141592653589793238462643

#ifndef ARRAY_H
#define ARRAY_H

#include <vector>
#include <boost/preprocessor.hpp>

#ifndef ALLOCATORS_H
#define ALLOCATORS_H

#include <cuda_runtime.h>

template< class T >
struct DefaultAllocator
{
	typedef T Elem;
	static void deallocate(T * p) { delete[] p; }
	static T * allocate(size_t s) { return new T[s]; }

	static void copy( T* begin, T* end, T* dst )
	{
		std::copy ( begin, end, dst );
	}

	static T* clone (T* begin, T* end)
	{
		T* p = allocate( end - begin );
		copy( begin, end, p );
		return p;
	}
};

template< class T >
struct DeviceAllocator
{
	typedef T Elem;
	static void deallocate(T * p) { cudaFree(p); }
	static T * allocate(size_t s)
	{
		void* p;
		cudaMalloc(&p, s * sizeof(T) );
		return (T*)p;
	}

	static void copy( T* begin, T* end, T* dst )
	{
		cudaMemcpy( dst, begin, (end-begin)*sizeof(T), cudaMemcpyDeviceToDevice );
	}

	static T* clone (T* begin, T* end) {
		T* p = allocate( end - begin );
		copy( begin, end, p );
		return p;
	}
};

template< class T >
struct HostAllocator
{
	typedef T Elem;
	static void deallocate(T * p) { cudaFreeHost(p); }
	static void deallocate(T * p, int size) { cudaFreeHost(p); }
	static T * allocate(size_t s)
	{
		T* p;
		cudaMallocHost(&p, s * sizeof(T) );
		return p;
	}

	static void copy( T* begin, T* end, T* dst )
	{
		cudaMemcpy( dst, begin, (end-begin)*sizeof(T), cudaMemcpyHostToHost );
	}

	static T* clone (T* begin, T* end)
	{
		T* p = allocate( end - begin );
		copy( begin, end, p );
		return p;
	}
};

template< class T >
struct MappedHostAllocator : public HostAllocator<T>
{
	static T * allocate(size_t s)
	{
		T* p;
		cudaHostAlloc(&p, s * sizeof(T), cudaHostAllocMapped );
		return p;
	}

	static T* getDevicePointer(T* hp)
	{
		T* dp;
		cudaGetDevicePointer(&dp,hp,0);
		return dp;
	}
};

template< class A, class T>
void alloc_copy(A,A, T* begin, T* end, T* dst)
{
	A::copy(begin,end,dst);
}

template< class T>
void alloc_copy(DefaultAllocator<T>,DeviceAllocator<T>, T* begin, T* end, T* dst)
{
	cudaMemcpy(dst, begin, (end-begin)*sizeof(T), cudaMemcpyHostToDevice);
}

template< class T>
void alloc_copy(DeviceAllocator<T>,DefaultAllocator<T>, T* begin, T* end, T* dst)
{
	cudaMemcpy(dst, begin, (end-begin)*sizeof(T), cudaMemcpyDeviceToHost);
}

#endif

#ifndef COMMON_H
#define COMMON_H

#define imin(a,b)	(a<b?a:b)
#define imax(a,b)	(a<b?b:a)

#define TILE_DIM	4

typedef __int32 index_t;

#include <complex>
typedef std::complex<float> ComplexFloat;
typedef std::complex<double> ComplexDouble;
//typedef ComplexFloat Complex;
//typedef ComplexDouble Complex;

#define CONFIDENCE_INTERVAL					10;
#define CONFIDENCE_INTERVAL_FLOAT			1E-6;
#define CONFIDENCE_INTERVAL_DOUBLE			1E-16;


/* Some handy stuff */
#define CUDA_CALL(value) do {		           								      \
	cudaError_t _m_cudaStat = value;										          \
	if (_m_cudaStat != cudaSuccess) {									          	\
		fprintf(stderr, "Error %s at line %d in file %s\n",					\
				cudaGetErrorString(_m_cudaStat), __LINE__, __FILE__);		\
		exit(-1);        													                  \
	} } while(0)
 
#define CUBLAS_CALL(value) do {                                                                 \
	cublasStatus_t _m_status = value;                                                             \
	if (_m_status != CUBLAS_STATUS_SUCCESS){                                                      \
		fprintf(stderr, "Error %d at line %d in file %s\n", (int)_m_status, __LINE__, __FILE__);    \
	exit(-2);                                                                                     \
	}                                                                                             \
	} while(0)

#define CUFFT_CALL(value) do {                                                                 \
	cufftResult_t _m_status = value;                                                             \
	if (_m_status != CUFFT_SUCCESS){                                                      \
		fprintf(stderr, "Error %d at line %d in file %s\n", (int)_m_status, __LINE__, __FILE__);    \
	exit(-3);                                                                                     \
	}                                                                                             \
	} while(0)
 
#define CURAND_CALL(x) do { if((x)!=CURAND_STATUS_SUCCESS) {  \
    printf("Error at %s:%d\n",__FILE__,__LINE__);             \
    exit(-4);}} while(0)
 
#define CUSPARSE_CALL(value) do {                                                                 \
	cusparseStatus_t _m_status = value;                                                             \
	if (_m_status != CUSPARSE_STATUS_SUCCESS){                                                      \
		fprintf(stderr, "Error %d at line %d in file %s\n", (int)_m_status, __LINE__, __FILE__);    \
	exit(-5);                                                                                     \
	}                                                                                             \
	} while(0)
 
#define CUSOLVER_CALL(value) do {                                                                 \
	cusolverStatus_t _m_status = value;                                                             \
	if (_m_status != CUSOLVER_STATUS_SUCCESS){                                                      \
		fprintf(stderr, "Error %d at line %d in file %s\n", (int)_m_status, __LINE__, __FILE__);    \
	exit(-5);                                                                                     \
	}                                                                                             \
	} while(0)


template <typename T>
struct Type2Type
{
	typedef T OriginalType;
};

class CudaDevice
{
    public:
        static CudaDevice& getInstance()
        {
            static CudaDevice instance;
		    return instance;
        }
    private:
        CudaDevice();
        
		CudaDevice(CudaDevice const&);
        void operator=(CudaDevice const&);
};

#endif

#ifndef NOMINMAX
#define NOMINMAX
#endif

#define NOMINMAX

typedef struct _matrixSize      // Optional Command-line multiplier for matrix sizes
{
    unsigned int Acols, Arows, Bcols, Brows, Ccols, Crows;
} sMatrixSize;

namespace matCUDA
{
	#undef min
	#undef max

	class ArrayDescriptor;
	class LinearIndexer;
	template <typename TElement, class TAllocator = MappedHostAllocator<TElement>> class ArrayData;

	template <typename TElement>
	class Array
	{
		template <typename TElement> friend class cublasOperations;
		template <typename TElement> friend class cufftOperations;
		template <typename TElement> friend class curandOperations;
		template <typename TElement> friend class cusolverOperations;
	public:

		Array(	ArrayDescriptor &descriptor,
				const TElement& defaulTElement = TElement());
	
		Array(Array &source);

		#define rep(z, n, text) \
		descriptor.push_back(x ## n);

		#define rep2(z, n, text) \
			*x##n

		#if !BOOST_PP_IS_ITERATING

		   #ifndef FILE_H_
		   #define FILE_H_

		   #include <boost/preprocessor/iteration/iterate.hpp>

		   #define BOOST_PP_FILENAME_1 "file.h"
		   #define BOOST_PP_ITERATION_LIMITS (1, 32)
		   #include BOOST_PP_ITERATE()

		   #endif

		#else

			Array(	BOOST_PP_ENUM_PARAMS(BOOST_PP_ITERATION(), const index_t x))
					: m_data(1 BOOST_PP_REPEAT(BOOST_PP_ITERATION(), rep2, ~)),
					m_indexer(NULL),
					m_padded(false)
			{
				std::vector<index_t> descriptor;
				BOOST_PP_REPEAT(BOOST_PP_ITERATION(), rep, ~)

				int elements = m_data.m_numElements;
				if(descriptor.size() == 1)
				{
					descriptor.push_back(1);
					m_padded = true;
				}
		
				m_indexer = new LinearIndexer(descriptor);
			}

		#endif

		~Array();
	
		// info from base classes
		const ArrayData<TElement>* GetArrayData() const { return &m_data; }
		ArrayDescriptor& GetDescriptor();

		// operators
		bool operator == (Array<TElement>& a);
		bool operator != (Array<TElement>& a);
		const TElement& operator () (index_t u, ...) const;
		TElement& operator () (index_t u, ...);
		Array<TElement>& operator = (Array<TElement> &a);
		Array<TElement>& operator = (TElement &a);
		Array<TElement> operator + (Array<TElement>  &a); // gpu
		Array<TElement> operator + (TElement a);
		Array<TElement> operator - (Array<TElement> &a); // gpu
		Array<TElement> operator - (TElement a);
		Array<TElement> operator * (Array<TElement> &a); // gpu
		Array<TElement> operator * (TElement a);
		Array<TElement> operator / (Array<TElement> &a); // gpu
		Array<TElement> operator / (TElement a);
		Array<TElement>& operator += (Array<TElement> &a); // gpu
		Array<TElement>& operator -= (Array<TElement> &a); // gpu
		Array<TElement>& operator *= (Array<TElement> &a); // gpu

		// functions
		Array<TElement> acos();
		Array<TElement> acosd();
		void			Array2cuSparseCooMatrix( int n, int nnz, int *cooRowIndexHostPtr, int *cooColIndexHostPtr, TElement *cooValHostPtr ); 
		Array<TElement> asin();
		Array<TElement> asind();
		Array<TElement> atan();
		Array<TElement> atand();
		bool			check_close( Array<TElement> a );
		Array<TElement> conj(); // gpu
		Array<TElement> conjugate(); // gpu
		Array<TElement> cos();
		Array<TElement> cosd();
		TElement		determinant(); // gpu
		Array<TElement> detrend(); // gpu + cpu
		Array<TElement> diff();
		Array<TElement> eig( Array<TElement> *eigenvectors ); // gpu + cpu
		Array<TElement> fft(); // gpu
		size_t			getDim( index_t dim ) { return this->GetDescriptor().GetDim( dim ); };
		size_t			getNDim() { return this->GetDescriptor().GetNDim(); };
		Array<TElement> getColumn( const index_t col );
		Array<TElement> hermitian(); // gpu
		Array<TElement> invert(); // gpu
		Array<TElement> LS( Array<TElement> A ); // gpu
		void			LU( Array<TElement> *L, Array<TElement> *U, Array<TElement> *P ); // gpu
		Array<TElement>	max(); // gpu
		Array<TElement>	max( Array<TElement> *idx ); // gpu
		Array<TElement>	min(); // gpu
		Array<TElement>	min( Array<TElement> *idx ); // gpu
		Array<TElement> minor(const int row, const int column);
		TElement		norm(); // gpu
		void			print();
		void			QR( Array<TElement> *Q, Array<TElement> *R ); // gpu
		Array<TElement> sin();
		Array<TElement> sind();
		Array<TElement> submatrix( const index_t rowBegin, const index_t rowEnd, const index_t colBegin, const index_t colEnd ); // partial
		Array<TElement> tan();
		Array<TElement> tand();
		Array<TElement> transpose(); // gpu
		void			write2file( std::string s = arrayname2str() );

		// TODO functions
		Array<TElement> addColumn( Array<TElement> *col_to_add ); // TODO
		Array<TElement> elementWiseAdd( Array<TElement> *A ); // TODO
		Array<TElement> elementWiseDivide( Array<TElement> *A ); // TODO
		Array<TElement> elementWiseMultiply( Array<TElement> *A ); // TODO
		Array<TElement> operator ^ (TElement a); // TODO
		Array<TElement> roots(); // TODO
		Array<TElement> sqrt(); // TODO

	private:
	
		static std::string	arrayname2str(); 
		ArrayData<TElement>	m_data;
		LinearIndexer		*m_indexer;
		bool				m_padded;	
	};

	class ArrayUtil 
	{
	public:
		static ArrayDescriptor& GetArrayDescriptor(int count, ...);
		static ArrayDescriptor& GetArrayDescriptor(ArrayDescriptor &source);
		static void ReleaseArrayDescriptor(ArrayDescriptor &descriptor);
	};

	class ArrayDescriptor
	{
		friend class ArrayUtil;
		friend class LinearIndexer;
		template <typename TElement> friend class Array;
		template <typename TElement> friend class cublasOperations;
		template <typename TElement> friend class cufftOperations;
		template <typename TElement> friend class curandOperations;
		template <typename TElement> friend class cusolverOperations;

	public:
		ArrayDescriptor(int count);
		ArrayDescriptor(ArrayDescriptor &source);
		ArrayDescriptor(std::vector<index_t> &source);
		ArrayDescriptor(int source[]);
		~ArrayDescriptor();
	
		int GetDim(int dim);
		int GetNDim();
		int GetNumberOfElements();
		bool operator == (const ArrayDescriptor &other) const;
		bool operator != (const ArrayDescriptor &other) const;
	
	private:
		void Swap();
		index_t *m_dim;
		int m_count;
	};

	template <typename TElement, class TAllocator>
	class ArrayData
	{
		template <typename TElement> friend class Array;
		template <typename TElement> friend class cublasOperations;
		template <typename TElement> friend class cufftOperations;
		template <typename TElement> friend class curandOperations;
		template <typename TElement> friend class cusolverOperations;

	public:
		ArrayData(	ArrayDescriptor &descriptor,
					const TElement &defaulTElement = TElement(),
					const TAllocator &allocator = TAllocator());

		ArrayData(	index_t numElements,
					const TAllocator &allocator = TAllocator());

		ArrayData(ArrayData &source);
		~ArrayData();

		const TElement& operator [] (index_t index) const;
		TElement& operator [] (index_t index);
		bool operator == (ArrayData<TElement, TAllocator> &a);
		bool operator != (ArrayData<TElement, TAllocator> &a);
		bool check_close( ArrayData<TElement, TAllocator> a );
		//bool operator > (ArrayData<TElement, TAllocator> &a);
		//bool operator < (ArrayData<TElement, TAllocator> &a);
		//bool operator >= (ArrayData<TElement, TAllocator> &a);
		//bool operator <= (ArrayData<TElement, TAllocator> &a);
		ArrayData<TElement, TAllocator>& operator = (ArrayData<TElement, TAllocator> &a);
		ArrayData<TElement, TAllocator> operator + (ArrayData<TElement, TAllocator> &a);
		ArrayData<TElement, TAllocator> operator - (ArrayData<TElement, TAllocator> &a);
		ArrayData<TElement, TAllocator>& operator += (ArrayData<TElement, TAllocator> &a);
		ArrayData<TElement, TAllocator>& operator -= (ArrayData<TElement, TAllocator> &a);
	
	private:
		void conj();
		void transpose(int width, int height);
		bool AlmostEqual2sComplement(double A, double B);
		bool areEqualRel( TElement a, TElement b );
		bool AlmostEqualRelativeAndAbs(TElement A, TElement B);

		TElement* GetElements() { return m_data; }
	
		TElement *m_data;
		index_t m_numElements;
		TAllocator m_allocator;
		index_t m_size;
	};

	class LinearIndexer
	{
		template <typename TElement> friend class Array;

	public:
		LinearIndexer(ArrayDescriptor &descriptor);
		LinearIndexer(std::vector<index_t> &descriptor);
		~LinearIndexer();

		ArrayDescriptor& GetDescriptor();
		index_t GetIndex() const;
		index_t GetSize() const;
		static index_t GetNeededBufferCapacity(ArrayDescriptor &descriptor);
		static index_t GetNeededBufferCapacity(std::vector<index_t> &descriptor);

	private:
		ArrayDescriptor m_descriptor;
		index_t *m_pos;
	};

	template <typename TElement>
	Array<TElement> eye(index_t N);
	template <typename TElement>
	Array<TElement> eye( index_t N );

	template <typename TElement>
	Array<TElement> dpss( index_t N, double NW, index_t degree );

	Array<ComplexFloat> fft( Array<float> *in );
	Array<ComplexDouble> fft( Array<double> *in );

	template <typename TElement>
	Array<TElement> read_file_vector( std::string s );

	template <typename TElement>
	Array<TElement> read_file_matrix( std::string s );

	template <typename TElement>
	Array<TElement> rand(index_t u);

	template <typename TElement>
	Array<TElement> rand(index_t u1, index_t u2);

	// measure time and print
	void tic();
	void toc();

	Array<ComplexFloat> Array_S2C( Array<float> ); // TODO
	Array<ComplexDouble> Array_D2Z( Array<double> ); // TODO
	//Array<TElement> transpose( Array<TElement> ); // TODO
	//Array<TElement> conj( Array<TElement> ); // TODO
	//Array<TElement> hermitian( Array<TElement> ); // TODO
	//Array<TElement> invert( Array<TElement> ); // TODO
	//TElement determinant( Array<TElement> ); // TODO
}

#endif
